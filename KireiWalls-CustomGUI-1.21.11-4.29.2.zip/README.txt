MCKireiWalls 4.29.2 Professional 4x Resource Pack
Target: Minecraft Java / Paper 1.21.11

Every custom bitmap uses a modern four-times source baseline. UI items, hotbar
controls, general font art, and Pirate companions use 64x64 cells. Scoreboard
symbols use exact 40x40 masters for their 10-pixel render size, avoiding blurry
non-integer scaling. The pack tile is 256x256. All five permanent hub controls
now have dedicated models instead of mixing three vanilla items with two
custom ones.

The custom ice-and-wind background is scoped exclusively to the hub /class
browser. Its premium 704x888 Blockbench master produces a carefully filtered
176x222 runtime image inside Minecraft's reliable 256x256 bitmap-font limit.
It renders at the exact functional inventory footprint. The raised plaque
contains a bold, centered KIREI wordmark. Editable files are
model-sources/Kirei_Class_GUI.bbmodel and
model-sources/Kirei_Class_GUI_4x.png. The Blockbench source contains 100 layered
elements: separate rails, chambers, divider, raised plaque, and all 90
individually extruded slot wells with a 2.1-unit depth hierarchy.

The five Pirate companion variants are ItemDisplay models. Item displays have
no interaction or collision hitbox, so the companions cannot absorb attacks or
block building while orbiting the Pirate player.

The previous hub NPC lineup, model assets, templates, and admin command are
retired and are intentionally not included in this pack.

Keep the ZIP intact and host it at a direct public HTTPS URL.
