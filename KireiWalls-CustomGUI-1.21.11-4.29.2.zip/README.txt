MCKireiWalls 4.29.2 Professional 4x Resource Pack
Target: Minecraft Java / Paper 1.21.11

Every custom bitmap now uses a modern four-times source baseline. UI item,
hotbar, scoreboard, font, and Pirate companion art is authored at 64x64 per
cell; the pack tile is 256x256. Minecraft still renders the assets at their
normal gameplay size, using the extra source pixels for cleaner sampling,
bevels, highlights, shadows, and material depth.

The custom ice-and-wind background is scoped exclusively to the hub /class
browser. Its premium 704x888 art is stored in a 1024x1024 font cell and renders
at the exact functional 176x222 inventory footprint. The raised plaque contains
a bold, centered KIREI wordmark. Editable files are
model-sources/Kirei_Class_GUI.bbmodel and
model-sources/Kirei_Class_GUI_4x.png. The Blockbench source contains 100 layered
elements: separate rails, chambers, divider, raised plaque, and all 90
individually extruded slot wells with a 2.1-unit depth hierarchy.

The five Pirate companion variants are ItemDisplay models. Item displays have
no interaction or collision hitbox, so the companions cannot absorb attacks or
block building while orbiting the Pirate player.

The previous hub NPC lineup, model assets, templates, and admin command are
retired and are intentionally not included in this pack.

Keep the ZIP intact and host it at a direct public HTTPS URL.
