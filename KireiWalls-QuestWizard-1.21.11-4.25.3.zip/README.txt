MCKireiWalls 4.20.0 Ultra UI + Exact NPC Resource Pack
Target: Minecraft Java / Paper 1.21.11
Samurai, Armored Oni, Egyptian Phoenix Oracle, Record Keeper, Gem Merchant, and Spartan.
Keep the ZIP intact and host it at a direct public HTTPS URL.

Crimson Samurai: exact user-supplied BBModel, 150 cubes, 17 hierarchical bones,
embedded 256x128 texture, weapon-free, and original four-second polished idle.

Gem Merchant: exact user-supplied BBModel, 68 cubes, 6 groups, embedded
128x128 texture, and no invented bone animation (global idle bob only).

Quest Wizard: exact QuestWizard.bbmodel, 37 source cubes, 12 groups,
37 byte-exact embedded textures, exact precomposed static cube poses,
no hologram, no particles, and no action.
