MCKireiWalls 4.21.0 Ultra UI + Exact NPC Resource Pack
Target: Minecraft Java / Paper 1.21.11
Samurai, Armored Oni, Egyptian Phoenix Oracle, Record Keeper, Gem Wizard, and Spartan.
Keep the ZIP intact and host it at a direct public HTTPS URL.

Crimson Samurai: exact user-supplied BBModel, 150 cubes, 17 hierarchical bones,
embedded 256x128 texture, weapon-free, and original four-second polished idle.

Gem Wizard: exact GemWizard2.bbmodel, 37 cubes, 12 preserved groups,
37 embedded texture files, arbitrary display-bone rotations, and no invented animation.
