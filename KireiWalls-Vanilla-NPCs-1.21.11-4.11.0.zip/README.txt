MCKireiWalls 4.11.0 High-Detail Vanilla NPC Resource Pack
Target: Minecraft Java / Paper 1.21.11
All model surfaces use Minecraft's built-in block textures.
Keep the ZIP intact and host it at a direct public HTTPS URL.
