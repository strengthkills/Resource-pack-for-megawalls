MCKireiWalls 4.19.0 Modern UI + Exact NPC Resource Pack
Target: Minecraft Java / Paper 1.21.11
Samurai, Armored Oni, Egyptian Phoenix Oracle, Record Keeper, Gem Merchant, and Spartan.
Keep the ZIP intact and host it at a direct public HTTPS URL.

Crimson Samurai: exact user-supplied BBModel, 150 cubes, 17 hierarchical bones,
embedded 256x128 texture, weapon-free, and original four-second polished idle.

Gem Merchant: exact user-supplied BBModel, 68 cubes, 6 groups, embedded
128x128 texture, and no invented bone animation (global idle bob only).
