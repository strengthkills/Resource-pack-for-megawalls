MCKireiWalls 4.14.0 Blockbench-Style Animated NPC Resource Pack
Target: Minecraft Java / Paper 1.21.11
Includes dedicated pixel textures, articulated accessories, and 43 display bones.
Keep the ZIP intact and host it at a direct public HTTPS URL.
