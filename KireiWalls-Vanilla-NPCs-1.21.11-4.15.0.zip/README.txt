MCKireiWalls 4.15.0 Clean Cuboid NPC Resource Pack
Target: Minecraft Java / Paper 1.21.11
Samurai, Oni, Phoenix Oracle, Record Keeper, Witch, and Spartan.
All preview sheets are rendered from these exact model JSON files.
Keep the ZIP intact and host it at a direct public HTTPS URL.
