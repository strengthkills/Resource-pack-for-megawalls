MCKireiWalls 4.15.0 Exact Blockbench Samurai Resource Pack
Target: Minecraft Java / Paper 1.21.11
Samurai, Armored Oni, Egyptian Phoenix Oracle, Record Keeper, Witch, and Spartan.
All QA previews are rendered directly from these exact model JSON files.
Keep the ZIP intact and host it at a direct public HTTPS URL.

Crimson Samurai: exact user-supplied BBModel, 150 cubes, 17 hierarchical bones,
embedded 256x128 texture, weapon-free, and the original four-second polished idle.
