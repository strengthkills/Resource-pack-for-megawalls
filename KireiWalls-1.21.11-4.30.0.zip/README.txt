MCKireiWalls 4.30.0 Class GUI + Hitbox-Free Pirate Companions
Target: Minecraft Java / Paper 1.21.11
Keep the ZIP intact and host it at a direct public HTTPS URL.

The /class inventory uses the exact 256x256 texture embedded in
model-sources/Kirei_Class_Menu.bbmodel. Its 176x222 visible area maps to the
real 9-column chest, player inventory, and hotbar slot geometry.

The class background is intentionally restricted to /class. Match-server
waiting lobbies use the standard inventory background and a focused class
selector so resource-pack artwork cannot cover or shift that interface.

Pirate companions use five ItemDisplay model variants. They have no combat or
block-placement hitbox while preserving the orbit and attack visuals.

All retired hub NPC models, item registrations, textures, manifests, and model
sources were removed from this pack.
