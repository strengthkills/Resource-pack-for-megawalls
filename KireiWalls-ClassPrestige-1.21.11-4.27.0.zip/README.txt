MCKireiWalls 4.27.0 Class Prestige UI + Exact NPC Resource Pack
Target: Minecraft Java / Paper 1.21.11
Samurai, Armored Oni, Egyptian Phoenix Oracle, Record Keeper, Arcane Gemkeeper,
Quest Wizard, Spartan, and Ironbound Sentinel.
Keep the ZIP intact and host it at a direct public HTTPS URL.

Crimson Samurai: exact user-supplied BBModel, 150 cubes, 17 hierarchical bones,
embedded 256x128 texture, weapon-free, and original four-second polished idle.

Gem Merchant: exact user-supplied BBModel, 68 cubes, 6 groups, embedded
128x128 texture, and no invented bone animation (global idle bob only).

Quest Wizard: exact QuestWizard.bbmodel, 37 source cubes, 12 groups,
37 byte-exact embedded textures, exact precomposed static cube poses,
no hologram, no particles, and no action.

Ironbound Sentinel: exact user-edited geometry and embedded 64x64 texture,
41 cubes, 10 hierarchical groups, and one subtle four-second authored idle.

The hub scoreboard uses six native 16x16 custom glyphs rendered at a crisp
10-pixel line height. Permanent hotbar controls use dedicated Cosmetics and
Mystery Box item models so menu styling cannot replace them.
